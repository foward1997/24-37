package Product;

public class ProductManager {
	
	public void Add(Product product) {
		
		System.out.println("Ürün eklendi "+product.getName());
	}

}
