package DortIslem;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DortIslem dortIslem=new DortIslem();
		
		System.out.println(dortIslem.Bol(12, 3));
	}

}
