package İnheritance;

public class PersonManager {
	
	public void Add() {
		
		System.out.println("Kişi eklendi");
	}
	
	public void List() {
		
		System.out.println("Kişi listelendi");
		
	}

}
