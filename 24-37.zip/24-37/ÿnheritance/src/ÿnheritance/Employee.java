package İnheritance;

public class Employee extends Person{

	
	double salary;
}
