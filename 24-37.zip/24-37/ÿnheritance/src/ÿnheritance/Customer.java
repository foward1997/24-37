package İnheritance;

public class Customer extends Person{
	
	String adress;
	
	public void setAdress(String adress) {
		
		 this.adress=adress;
		
	}

}
