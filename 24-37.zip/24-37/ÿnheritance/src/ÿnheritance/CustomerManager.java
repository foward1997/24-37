package İnheritance;

public class CustomerManager extends PersonManager{
	
	

}
