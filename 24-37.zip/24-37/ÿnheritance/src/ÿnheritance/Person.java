package İnheritance;

public class Person {

}
