package İnheritanceDemo;

public class AskerKrediManager extends BaseKrediManager{

}
