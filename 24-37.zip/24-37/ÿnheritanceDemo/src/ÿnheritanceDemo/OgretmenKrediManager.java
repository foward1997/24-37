package İnheritanceDemo;

public class OgretmenKrediManager extends BaseKrediManager{

}
