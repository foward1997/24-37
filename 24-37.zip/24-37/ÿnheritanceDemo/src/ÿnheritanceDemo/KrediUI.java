package İnheritanceDemo;

public class KrediUI {
	
	public void KrediHesapla(BaseKrediManager baseKrediManager) {
		
		baseKrediManager.Hesapla();
		
	}

}
