package İnheritanceDemo;

public class TarimKrediManager extends BaseKrediManager{

}
