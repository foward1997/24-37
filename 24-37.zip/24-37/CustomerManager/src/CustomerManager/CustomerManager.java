package CustomerManager;

public class CustomerManager {
	
	public static void Add() {
		System.out.println("Müşteri Eklendi");
		
	}
	
	public static void Remove() {
		System.out.println("Müşteri Silindi");
		
		
	}
	
	public static void Update(){
		System.out.println("Müşteri bilgisi güncellendi");
		
		
	}
	
	

}
